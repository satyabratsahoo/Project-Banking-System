
SET serveroutput ON;
EXEC bs_cust_create_proc( '&Enter_Your_Full_Name', '&Enter_Father_Fullname', '&Enter_DOB_DD_MON_YYYY', '&Enter_permanent_address', '&Enter_Present_address', &Enter_Mobile_number_10_digit, &Enter_landline_number_12_digit, '&Enter_Pan_number_10_digit', '&Enter_branch_id', &Enter_Open_balance);
EXEC bs_cust_create_proc( 'ash ', 'ash', '15-AUG-1995', 'nayabazar', 'hyderabad', 9437020436, 943741143910, 'abcdefgh14', 'SBI2094', 1000);
SET SERVEROUTPUT ON;
EXEC bs_login_proc('&NAME','&PASSWORD');
exec bs_logout_proc();
EXEC BS_BALANCE_PROC;
EXEC BS_CHPSW_PROC('&OLD_PASSWORD','&NEW_PASSWORD');
exec bs_view_acc_proc;
exec BS_ADD_PAY_PROC(&account_no);
EXEC BS_ACTIVATE_PAY_PROC(&account_no);
EXEC BS_VIEW_PAY_PROC(&ACCOUNT_NO);
EXEC BS_DELETE_PAY_PROC(&ACC_NO);
EXEC BS_FUND_TRANSFER_PROC(&MY_ACC,&PAYEE_ACC,&AMOUNT);

SELECT A.ACC_AC_TYPE,C.CD_FULL_NAME,C.CD_PRE_ADD,B.BD_IFSC_CODE
FROM BS_ACCOUNTS_TB A,BS_BRANCH_DET_TB B,BS_CUSTDET_TB C
WHERE A.ACC_CUST_ID = C.CD_CUST_ID AND C.CD_BRANCH_ID = B.BD_BRANCH_ID
AND A.ACC_AC_NO = 1710001;
SET SERVEROUTPUT ON;

select substr(('satya brat'),1,instr(upper('satya brat'),' ')-1)||'@'||to_char(sysdate,'yyyy') from dual; --generate userid and password using substring 
                                                                                                                                               --and instring and concat functions.

SELECT SUBSTR(USERENV('SESSIONID'),-2)FROM DUAL;
SELECT USERENV('SESSIONID') FROM DUAL;
SELECT PROFILE FROM DBA_USERS WHERE USERNAME = USER;


create or replace directory  BS_GENERATE_STATEMENT as 'd:\BS_GENERATE_STATEMENT';

grant execute,read,write on BS_GENERATE_STATEMENT to bank_SYSTEM;
SELECT SYS_CONTEXT('USERENV','HOST') FROM DUAL;
SELECT SYS_CONTEXT('USERENV','IP_ADDRESS') FROM DUAL;
SELECT SYS_CONTEXT('USERENV','SERVICE_NAME') FROM DUAL;
SELECT SYS_CONTEXT('USERENV','SESSION_USER') FROM DUAL;
SELECT SYS_CONTEXT('USERENV','SESSION_USERID') FROM DUAL;
SELECT SYS_CONTEXT('USERENV','INSTANCE') FROM DUAL;
SELECT SYS_CONTEXT('USERENV','OS_USER') FROM DUAL;
SELECT SYS_CONTEXT('USERENV','AUTHENTICATED_IDENTITY') FROM DUAL;
SELECT SESSIONTIMEZONE FROM DUAL;
EXEC BS_ADD_PAY_PROC(&ACCNO)
EXEC BS_ACTIVATE_PAY_PROC(&ACCNO)
select (sysdate-(sysdate-365)) from dual

WITH months_diftab AS (SELECT MONTHS_BETWEEN(TRUNC(SYSDATE), TO_DATE('10/09/2010','DD/MM/YYYY') ) months_dif FROM DUAL)
SELECT TRUNC(months_dif/12) years, TRUNC(months_dif) months , TRUNC(SYSDATE)- ADD_MONTHS(TO_DATE('10/09/2010','DD/MM/YYYY'),
TRUNC(months_dif)) days FROM months_diftab;

select 15000 * power((1+5/100/4),4*24/12) from dual

SELECT MONTHS_BETWEEN(TRUNC(SYSDATE), TO_DATE('10/09/2010','DD/MM/YYYY') ) months_dif,
trunc(months_dif/12)years,trunc(months_dif)months,
FROM DUAL

select trunc(sysdate) from dual;
select sysdate from dual;

select trunc(sysdate - to_date('10/09/2015' ,'dd/mm/yyyy'))from dual;

select sysdate + 1/2/2 year from dual;
SELECT ROUND(1000 * power(1 + (0.05 * 12)/10,4*10/12)) FROM DUAL  

select TO_DATE('10/09/2015', 'DD-mm-yyyy' ) from dual;
EXEC BS_FIXED_ACC_PROC(&amount,&tenure,&interest);
EXEC BS_REC_ACC_PROC(&amount,&tenure,&interest);
set serveroutput on;

select ROUND((100 *( power(1+15/400,4) - 1)) / (1 - power(1+15/400,-1/3))) from DUAL;
show errors;
exec bs_close_fd_proc;
exec bs_close_rd_proc;