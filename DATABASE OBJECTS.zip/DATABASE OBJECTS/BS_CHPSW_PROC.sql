--PROCEDURE FOR CHANGE PASSWORD OF CUSTOMER IN THE BANKING SYSTEM APPLICATION
/**********************************************************************
/*
/* Filename: BS_CHPSW_PROC.sql
/* Members:1.Satyabrat Sahoo (@satyabratsahoo.kc)gmail,linkdein,skype
/* Version: 1.0
/* Revision :1.0 
/* Copyright (c) 2015, Inc. All rights reserved.
/* Date: 8th Dec 2015
/* Description: Procedure Change password is to change the password of customer in  Banking System Application
/*by using the userid and password of the user and validating them.
/**********************************************************************/
CREATE OR REPLACE PROCEDURE BS_CHPSW_PROC(
p_password BS_USER_CRED_TB.UC_PASSWORD%TYPE,
p_new_psw BS_USER_CRED_TB.UC_PASSWORD%TYPE)
AS
---------------------------------------------------------------VARIABLE DECLARATION-----------------------------------------------------------------
vr_user_id BS_USER_CRED_TB.UC_USER_ID%TYPE;
vr_password BS_USER_CRED_TB.UC_PASSWORD%TYPE;
nm_session  NUMBER(10);
------------------------------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN

SELECT SYS_CONTEXT('USERENV','SESSIONID') INTO nm_session FROM DUAL;          --selecting current session id from dual and stored into a variable.

SELECT UC_USER_ID,UC_PASSWORD INTO vr_user_id,vr_password                             --selecting user id and password of current session id
FROM BS_USER_CRED_TB WHERE UC_SESSION_ID = nm_session;

IF(vr_password = p_password) THEN                                                                               --if condition to check password
UPDATE BS_USER_CRED_TB SET UC_PASSWORD = p_new_psw
WHERE UC_USER_ID = vr_user_id;
DBMS_OUTPUT.PUT_LINE('PASSWORD FOR USER ID : '||vr_user_id||' CHANGED SUCCESSFULLY');       --if above condition satisfied then password changed successfully
ELSE
DBMS_OUTPUT.PUT_LINE('WRONG  PASSWORD. PLEASE CHECK AND TRY AGAIN!');                        --otherwise wrong password..check and try.
END IF;
---------------------------------------------------------------EXCEPTION SECTION-------------------------------------------------------------------------
EXCEPTION                                --if no one is logged in then no_data_found exception arrises.
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('PLEASE LOG IN TO CHANGE PASSWORD');

WHEN OTHERS THEN
DBMS_OUTPUT.PUT_LINE('----------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('UNEXPECTED ERROR.  ERROR CODE:ALEX007');
DBMS_OUTPUT.PUT_LINE('----------------------------------------------------------------------------------');

END;
/
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------