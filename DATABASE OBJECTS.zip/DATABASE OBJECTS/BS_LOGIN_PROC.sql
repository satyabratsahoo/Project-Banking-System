--PROCEDURE FOR LOGIN TO THE BANKING SYSTEM APPLICATION
/*************************************************************************************
/*
/* Filename: BS_LOGIN_PROC.sql
/* Members: 1.Satyabrat Sahoo (@satyabratsahoo.kc)gmail,linkdein,skype
/* Version: 1.0
/* Revision :1.0 
/* Copyright (c) 2015, Inc. All rights reserved.
/* Date: 8th Dec 2015
/* Description: Procedure Login is to access Banking System Application
/*by using the userid and password of the user and validating them.
/*****************************************************************************************/
CREATE OR REPLACE PROCEDURE BS_LOGIN_PROC(p_user_id BS_USER_CRED_TB.UC_USER_ID%TYPE,
                                       p_password BS_USER_CRED_TB.UC_PASSWORD%TYPE)
AS

---------------------------------------VARIABLE DECLARATION-----------------------------------------------------
nm_login_status                               NUMBER(1);
nm_session_id                                NUMBER(15);
vr_user_id                                       BS_USER_CRED_TB.UC_USER_ID%TYPE;
vr_password                                   BS_USER_CRED_TB.UC_PASSWORD%TYPE;
vr_current_session                          NUMBER(15);
nm_count_cs                                   NUMBER(15);
vr_user_type                                   CHAR(1);
vr_name                                         VARCHAR2(50);
--------------------------------------------------------------------------------------------------------------------------------------
BEGIN

SELECT UC_SESSION_ID,UC_LOGIN_STATUS,UC_USER_TYPE                       
INTO nm_session_id,nm_login_status,vr_user_type                                 --selecting the session id,status and usertype of the userid in actual parameters
FROM BS_USER_CRED_TB WHERE UC_USER_ID = p_user_id;              -- storing the above datas to their respective variables.

SELECT UC_USER_ID,UC_PASSWORD
INTO vr_user_id,vr_password                                                                       
FROM BS_USER_CRED_TB 
WHERE UC_USER_ID=p_user_id;

SELECT SYS_CONTEXT('USERENV','SESSIONID')                                   -- selecting the current session number from userenv.
INTO vr_current_session  
FROM DUAL;

SELECT COUNT(*)                                                                                  -- to count the no. of user in the same session from the login table.
INTO nm_count_cs 
FROM BS_USER_CRED_TB 
WHERE UC_SESSION_ID= vr_current_session;

IF(vr_user_id = p_user_id AND vr_password = p_password)THEN             -- if condition to check wether the username and password is correct

    IF(nm_login_status=0 AND nm_session_id=0 AND nm_count_cs=0 AND vr_user_type = 'C') THEN   --login conditions for customers
        UPDATE BS_USER_CRED_TB SET UC_LOGIN_STATUS=1 WHERE UC_USER_ID=vr_user_id;
        UPDATE BS_USER_CRED_TB SET UC_SESSION_ID = vr_current_session
        WHERE UC_USER_ID=vr_user_id;
        
       SELECT CD_FULL_NAME INTO vr_name FROM BS_CUSTDET_TB
       WHERE CD_USER_ID = vr_user_id;
       DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------');
        DBMS_OUTPUT.PUT_LINE('WELCOME MR./MS.'||vr_name);
        DBMS_OUTPUT.PUT_LINE('YOU ARE LOGGED IN SUCCESSFULLY...');
        DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------');
        
        ELSIF(nm_login_status=0 AND nm_session_id=0 AND nm_count_cs=0 AND vr_user_type = 'A') THEN    --login conditions for Admin
        UPDATE BS_USER_CRED_TB SET UC_LOGIN_STATUS=1 WHERE UC_USER_ID=vr_user_id;
        UPDATE BS_USER_CRED_TB SET UC_SESSION_ID = vr_current_session
        WHERE UC_USER_ID=vr_user_id;
        
       
       DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------');
        DBMS_OUTPUT.PUT_LINE('WELCOME MR./MS.ADMINISTRATOR-'||vr_user_id);
        DBMS_OUTPUT.PUT_LINE('YOU ARE LOGGED IN SUCCESSFULLY...');
        DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------');
        
    ELSIF(nm_login_status=1 AND nm_session_id=vr_current_session  ) THEN      --if status = 1 and session = current session then user already logged in
    DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------');
      DBMS_OUTPUT.PUT_LINE('USER : '||vr_user_id||' ALREADY LOGGED IN SAME SYSTEM ');
      DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------');
      
    ELSIF(nm_login_status=0 AND nm_count_cs <> 0) THEN  -- someone is already logged in as count of session > 0
      DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------------------------------------------------------------------------------------');
      DBMS_OUTPUT.PUT_LINE('SOME OTHER USER IS ALREADY LOGGED IN, PLEASE CONTINUE AFTER HIS/HER LOG OUT.');
      DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------------------------------------------------------------------------------------');
      
    ELSIF(nm_login_status= 1 AND nm_session_id <> vr_current_session)THEN --the user is logged in some where.
      DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------------------------------------------------------------------------------------');
      DBMS_OUTPUT.PUT_LINE('USER : '||vr_user_id||' ALREADY LOGGED IN DIFFERENT SYSTEM,PLEASE LOG OUT THERE');
      DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------------------------------------------------------------------------------');
    END IF;
ELSE                                  -- if above if else condition doesnt satisfy then the password is wrong
DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('WRONG  PASSWORD');
DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------');
END IF;
COMMIT;

-----------------------------------------------EXCEPTION BLOCK--------------------------------------------------------------------------
EXCEPTION                      -- if the userid is not present in the table then no data found exception arises.
    WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------');
    DBMS_OUTPUT.PUT_LINE('USER : '||p_user_id||' DOES NOT EXIST');
    DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------------');
END;
/
----------------------------------------------------------------------------------------------------------------------------------------------------------