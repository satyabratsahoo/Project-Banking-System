--PROCEDURE TO VIEW DEPOSIT ACCOUNT BALANCE 
/*******************************************************************************
/*
/* Filename: BS_VIEWDEPOSIT_PROC.sql
/* Members: 1.Satyabrat Sahoo (@satyabratsahoo.kc)gmail,linkdein,skype
/* Version: 1.0
/* Revision :1.0 
/* Copyright (c) 2015, Inc. All rights reserved.
/*Date : 8th Dec 2015
/* Description: Procedure View Balance is used to view
/*the balance of the deposits accounts of the currently logged in user.
/*********************************************************************************/
CREATE OR REPLACE PROCEDURE BS_VIEWDEPOSIT_PROC
AS

---------------------------VARIABLE DECLARATION--------------------------------------
nm_savings  BS_ACCOUNTS_TB.ACC_BALANCE%TYPE;
nm_currents BS_ACCOUNTS_TB.ACC_BALANCE%TYPE;
nm_session NUMBER(13);
nm_sav_acc NUMBER(10);
nm_cur_acc NUMBER(10);
rc_user BS_USER_CRED_TB%ROWTYPE;

------------------------------------CODE BLOCKS BEGINS-----------------------------------------------------
BEGIN
SELECT SYS_CONTEXT('USERENV','SESSIONID') INTO nm_session FROM DUAL;

SELECT * INTO rc_user FROM BS_USER_CRED_TB where UC_SESSION_ID = nm_session;

IF (rc_user.UC_USER_TYPE='A') THEN
DBMS_OUTPUT.PUT_LINE('SORRY, YOU ARE ADMIN. YOU CANNOT VIEW BALANCE.');
ELSE

SELECT ACC_BALANCE,ACC_AC_NO INTO nm_savings,nm_sav_acc FROM BS_ACCOUNTS_TB
WHERE ACC_AC_TYPE = 'SAVINGS' AND ACC_CUST_ID =
(SELECT CD_CUST_ID FROM BS_CUSTDET_TB WHERE CD_USER_ID = rc_user.UC_USER_ID) ;

SELECT ACC_BALANCE,ACC_AC_NO INTO nm_currents,nm_cur_acc FROM BS_ACCOUNTS_TB
WHERE ACC_AC_TYPE = 'CURRENTS' AND ACC_CUST_ID =
(SELECT CD_CUST_ID FROM BS_CUSTDET_TB WHERE CD_USER_ID = rc_user.UC_USER_ID) ;

DBMS_OUTPUT.PUT_LINE('----------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('SAVINGS ACCOUNT NO : '||nm_sav_acc);
DBMS_OUTPUT.PUT_LINE('BALANCE : Rs.'||nm_savings);
DBMS_OUTPUT.PUT_LINE('----------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('CURRENT ACCOUNT NO : '||nm_cur_acc);
DBMS_OUTPUT.PUT_LINE('BALANCE : Rs.'||nm_currents);
DBMS_OUTPUT.PUT_LINE('----------------------------------------------------------------------------------');
END IF;
EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('NO DATA FOUND. CHECK LOGIN CREDENTIALS');
END;
/
