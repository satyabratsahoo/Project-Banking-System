--PROCEDURE TO CLOSE RD ACCOUNT IN BANKING SYSTEM APPLICATION
/***********************************************************************************************************************************************************************/
/*
/* Filename: BS_CLOSE_RD_PROC.sql
/* Members:              1.Satyabrat Sahoo (@satyabratsahoo.kc)gmail,linkdein,skype
/* Version: 1.0
/* Revision :1.0 
/* Copyright (c) 2015, Inc. All rights reserved.
/* Date: 8th Dec 2015
/* Description: Procedure Close RD to close RD accounts in Banking System Application

/***********************************************************************************************************************************************************************/
CREATE OR REPLACE PROCEDURE BS_CLOSE_RD_PROC
AS
--------------------------------------------------------------------------VARIABLE DECLARATION-----------------------------------------------------------------------------------------------
nm_session NUMBER(13);
rc_user BS_USER_CRED_TB%ROWTYPE;
rc_reccur BS_REC_DEPO_TB%ROWTYPE;
vr_account_type VARCHAR2(10);
nm_interest_amt  NUMBER(15,2);
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN

SELECT SYS_CONTEXT('USERENV','SESSIONID')                              --selecting current session id from dual and stored into a variable
INTO nm_session
FROM DUAL;
 
SELECT *                                                        --selecting all the rows from user credential table into a record type variable where session id equals to current session id  
INTO rc_user
FROM BS_USER_CRED_TB 
WHERE UC_SESSION_ID = nm_session;

IF (rc_user.UC_USER_TYPE = 'A') THEN              ---if condition to check user type..if user type is A then admin cannot close accounts
DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('SORRY YOU ARE ADMIN. AUTHORISATION DISABLED FOR YOU');
DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------------------------------------------------------');
END IF;

SELECT *                                                         --selecting all the rows from recurring deposit table by using subquery and stored them into a record type variable                               
INTO rc_reccur 
FROM BS_REC_DEPO_TB
WHERE RD_CUST_ID =(SELECT CD_CUST_ID
FROM BS_CUSTDET_TB
WHERE CD_USER_ID = rc_user.UC_USER_ID);


UPDATE BS_ACCOUNTS_TB                                 --updating the accounts table
SET ACC_BALANCE = ACC_BALANCE + rc_reccur.RD_MAT_AMT 
WHERE ACC_AC_TYPE = 'SAVINGS'
AND ACC_CUST_ID = rc_reccur.RD_CUST_ID;

nm_interest_amt :=rc_reccur.RD_MAT_AMT - rc_reccur.RD_AMT ;           --calculating interest amount

DELETE                                                                     --deleting from recurring deposit table 
FROM BS_REC_DEPO_TB 
WHERE RD_CUST_ID = rc_reccur.RD_CUST_ID;

COMMIT;

DBMS_OUTPUT.PUT_LINE('========RECCURING DEPOSIT ACCOUNT CLOSED========');
DBMS_OUTPUT.PUT_LINE('= ACCOUNT NUMBER    :  '||rc_reccur.RD_ACC_NO);
DBMS_OUTPUT.PUT_LINE('= OPENING DATE          :  '||rc_reccur.RD_OPEN_DATE);
DBMS_OUTPUT.PUT_LINE('= MATURITY DATE         :  '||rc_reccur.RD_MAT_DATE);
DBMS_OUTPUT.PUT_LINE('= TIME PERIOD              :  '||rc_reccur.RD_TENURE||' MONTHS');
DBMS_OUTPUT.PUT_LINE('= DEPOSITED AMOUNT :  RS.'||rc_reccur.RD_AMT);
DBMS_OUTPUT.PUT_LINE('= MATURITY AMOUNT    :  RS.'||rc_reccur.RD_MAT_AMT);
DBMS_OUTPUT.PUT_LINE('= INTEREST AMT           :  RS.'||nm_interest_amt );
DBMS_OUTPUT.PUT_LINE('MONEY TRANSFERRED TO YOUR SAVINGS A/C. CHK IT');
DBMS_OUTPUT.PUT_LINE('==============================================');


------------------------------------------------------------------------------EXCEPTION   SECTION-----------------------------------------------------------------------------------------------
EXCEPTION                              --if you dont have any RD account then no_data_found exception will arrise
WHEN NO_DATA_FOUND THEN

DBMS_OUTPUT.PUT_LINE('===============================================');
DBMS_OUTPUT.PUT_LINE('=YOU DO NOT HOLD ANY RECCURING DEPOSIT ACCOUNT=');
DBMS_OUTPUT.PUT_LINE('===============================================');

WHEN OTHERS THEN
DBMS_OUTPUT.PUT_LINE('----------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('UNEXPECTED ERROR.  ERROR CODE:ALEX007');
DBMS_OUTPUT.PUT_LINE('----------------------------------------------------------------------------------');


END;
/
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
