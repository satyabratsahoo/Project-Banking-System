--PROCEDURE TO CREATE A RECURRING DEPOSIT ACCOUNT IN THE BANKING SYSTEM APPLICATION
/***********************************************************************************************************************************************************************/
/*
/* Filename:  BS_REC_ACC_PROC .sql
/* Members:               1.Satyabrat Sahoo (@satyabratsahoo.kc)gmail,linkdein,skype
/* Version: 1.0
/* Revision :1.0 
/* Copyright (c) 2015, Inc. All rights reserved.
/* Date: 8th Dec 2015
/* Description: Procedure Recurring Deposit account to create an account for recurring deposit 
/*by using installment,tenure and interest we can open a reccuring deposit account
/***********************************************************************************************************************************************************************/
CREATE OR REPLACE PROCEDURE BS_REC_ACC_PROC(
p_inst           BS_REC_DEPO_TB.RD_MON_INS%TYPE,
p_tenure       BS_REC_DEPO_TB.RD_TENURE%TYPE,
p_interest      BS_REC_DEPO_TB.RD_CURR_IR%TYPE
)
AS
--------------------------------------------------------------------------VARIABLE DECLARATION-----------------------------------------------------------------------------------------------
nm_session          NUMBER(13);
rc_user             BS_USER_CRED_TB%ROWTYPE;
dt_maturity           DATE;
nm_maturity_amt   NUMBER(15,2);
nm_cust_id          NUMBER(13);
nm_acc_no         NUMBER(10);
e_min_tenure      EXCEPTION;
e_check_interest EXCEPTION;
e_check_amt       EXCEPTION;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN

SELECT SYS_CONTEXT('USERENV','SESSIONID')         --selecting current session id from dual and stored into a variable
INTO nm_session 
FROM DUAL; 

SELECT *                                                                    --selecting all the rows from user credential table into a record type variable where session id equals to current session id  
INTO rc_user                                                                                   
FROM BS_USER_CRED_TB
WHERE UC_SESSION_ID = nm_session;                        

IF (rc_user.UC_USER_TYPE = 'A') THEN                         ---if condition to check user type..if user type is A then admin cannot open accounts

DBMS_OUTPUT.PUT_LINE('-------------------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('SORRY YOU ARE ADMIN. YOU CANNOT OPEN ACCOUNTS');
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');
END IF;

SELECT CD_CUST_ID                                                          --selecting customer id from customer details table and stored into a variable
INTO nm_cust_id FROM BS_CUSTDET_TB 
WHERE CD_USER_ID = rc_user.UC_USER_ID;

SELECT ADD_MONTHS(SYSDATE,p_tenure) INTO dt_maturity FROM DUAL;

IF(p_tenure >=6 AND p_interest <= 100 AND p_inst >=100) THEN                --if condition to check tenure,intrest and installment amount

SELECT rec_acc_seq_s.NEXTVAL INTO nm_acc_no FROM DUAL;                --selecting next value of recurring account sequence from dual and stored into a variable 


nm_maturity_amt := ROUND((p_inst *( power(1+p_interest/400,4*p_tenure/12) - 1)) / (1 - power(1+p_interest/400,-1/3)));  --calculating maturity amount

INSERT INTO BS_REC_DEPO_TB VALUES(                                   --inserting data into recurring deposit table
nm_cust_id,
nm_acc_no,
p_inst,
p_inst*p_tenure,
SYSDATE,
p_tenure,
p_interest,
dt_maturity,
nm_maturity_amt
);

COMMIT;


DBMS_OUTPUT.PUT_LINE('----------------------------RECURRING DEPOSIT CREATED SUCCESSFULLY---------------------------------');
DBMS_OUTPUT.PUT_LINE('ACCOUNT NO: '||nm_acc_no);
DBMS_OUTPUT.PUT_LINE('TENURE OF DEPOSIT: '||p_tenure||' Months');
DBMS_OUTPUT.PUT_LINE('INTEREST RATE : '||p_interest||'%/ANNUM');
DBMS_OUTPUT.PUT_LINE('MONTHLY INSTALLMENT: Rs.'||p_inst);
DBMS_OUTPUT.PUT_LINE('ESTIMATED MATURITY DATE: '||dt_maturity);
DBMS_OUTPUT.PUT_LINE('ESTIMATED MATURITY AMOUNT: Rs.'||nm_maturity_amt);
DBMS_OUTPUT.PUT_LINE('---------------------------------------------------------------------------------------------------------------------------------');

END IF;

IF (p_tenure < 6) THEN                                                    --if condition to check tenure..if this condition satisfy then raise e_min_tenure exception
RAISE e_min_tenure;
END IF;

IF(p_interest > 100) THEN                                                   --if condition to check interest..if this condition satisfy then raise e_check_interest exception
RAISE e_check_interest;
END IF;

IF(p_inst < 100) THEN                                                          --if condition to check installment amount..if this condition satisfy then raise e_check_amt exception
RAISE e_check_amt;
END IF;
------------------------------------------------------------------------------EXCEPTION   SECTION-----------------------------------------------------------------------------------------------
EXCEPTION                                            --if tenure < 6  then e_min_tenure exception will arrise 
WHEN e_min_tenure THEN
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('MINIMUM TENURE TIME SHOULD BE 6 MONTHS.');
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');

WHEN e_check_amt THEN                         --if amount < 100  then e_check_amt exception will arrise 
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('MINIMUM INSTALLMENT SHOULD BE  RS.100.');
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');

WHEN e_check_interest THEN                         --if interest>=100  then e_check_interest exception will arrise 
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('INTEREST RATE SHOULD BE EQUAL OR LESS THAN 100%.');
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');

WHEN DUP_VAL_ON_INDEX THEN                   --if you have already a fd account then dup_val_on_index exception will arrise
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('YOU ALREADY HAVE A RECURRING DEPOSIT ACCOUNT.');
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');

WHEN NO_DATA_FOUND THEN                         --if there is an error while connecting to server then no_data_found exception will arrise
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');
DBMS_OUTPUT.PUT_LINE('ERROR WHILE CONNECTIONG TO SERVER.');
DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------------------');

END;
/
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------